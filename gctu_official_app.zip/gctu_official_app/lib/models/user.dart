class User{
  String uid;
  User({required this.uid});
}