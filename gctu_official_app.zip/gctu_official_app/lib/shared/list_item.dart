class Listitem{
  String imgUrl;
  String newsTitle;
  String author;
  String date;

  Listitem(this.imgUrl, this.newsTitle, this.author, this.date);
}