import 'package:flutter/material.dart';

class Global{

  static const List validEmail = ['test@gmail.com'];

}