import 'package:flutter/material.dart';

import 'components/body.dart';

class Lecturers_Sign_In extends StatelessWidget {
  static String routeName = "/Lecturers_Sign_In";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
