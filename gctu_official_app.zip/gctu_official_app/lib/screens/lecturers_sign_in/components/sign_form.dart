import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gctu_official_app/components/custom_surfix_icon.dart';
import 'package:gctu_official_app/components/form_error.dart';
import 'package:gctu_official_app/helper/keyboard.dart';
import 'package:gctu_official_app/screens/forgot_password/forgot_password_screen.dart';
import 'package:gctu_official_app/screens/lecturers_home/lecturers_home_screen.dart';
import 'package:gctu_official_app/screens/login_success/login_success_screen.dart';
import 'package:gctu_official_app/widgets/button_widgets.dart';

import '../../../components/default_button.dart';
import '../../../constants.dart';
import '../../../size_config.dart';

class SignForm extends StatefulWidget {
  @override
  _SignFormState createState() => _SignFormState();
}

class _SignFormState extends State<SignForm> {
  final _formKey = GlobalKey<FormState>();
  late String email;
  late String password;
  bool remember = false;
  final auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildEmailFormField(),
          SizedBox(height: 20),
          buildPasswordFormField(),
          SizedBox(height: 15),
          Row(
            children: [
              Checkbox(
                value: remember,
                activeColor: Colors.purple,
                checkColor: Colors.purple,
                onChanged: (value) {
                  setState(() {
                    remember = value!;
                  });
                },
              ),
              Text("Remember me",
                style: TextStyle(
                  color: Colors.purple,
                  fontFamily: 'roboto',
                  fontWeight: FontWeight.w900,
                ),
              ),
              Spacer(),
              GestureDetector(
                onTap: () => Navigator.pushNamed(
                    context, ForgotPasswordScreen.routeName),
                child: Text(
                  "Forgot Password",
                  style: TextStyle(decoration: TextDecoration.underline,
                    color: Colors.purple,
                    fontFamily: 'roboto',
                    fontWeight: FontWeight.w900,
                  ),
                ),
              )
            ],
          ),
          SizedBox(height: 15,),
          GestureDetector(
            onTap: (){
              FirebaseAuth.instance.signInWithEmailAndPassword(email: 'adminlecturer@live.gctu.edu.gh', password: 'Lect101@gctu').then((_){
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => Lecturers_Home_Screen()));
              });
            },
            child: ButtonWidget(),
          ),
        ],
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      obscureText: true,
      validator: (val){
        return val!.isEmpty ? "Enter Password" : null;
      },
      onChanged: (val) {
        password = val;
      },
      decoration: InputDecoration(
        labelText: "Password",
        hintText: "Enter your password",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Lock.svg", key: UniqueKey(),),
      ),
    );
  }
  TextFormField buildEmailFormField() {
    return TextFormField(
      keyboardType: TextInputType.emailAddress,
      validator: (val){
        return val!.isEmpty ? "Enter Email" : null;
      },
      onChanged: (val) {
        email = val;
      },
      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Enter your email",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon:CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg", key: UniqueKey(),),
      ),
    );
  }
}
