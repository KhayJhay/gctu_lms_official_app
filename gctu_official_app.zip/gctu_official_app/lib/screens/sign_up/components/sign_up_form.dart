import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:gctu_official_app/components/custom_surfix_icon.dart';
import 'package:gctu_official_app/components/default_button.dart';
import 'package:gctu_official_app/components/form_error.dart';
import 'package:gctu_official_app/helper/functions.dart';
import 'package:gctu_official_app/screens/complete_profile/complete_profile_screen.dart';

import 'package:gctu_official_app/constants.dart';
import 'package:gctu_official_app/screens/home/main_page.dart';
import 'package:gctu_official_app/services/auth.dart';
import 'package:gctu_official_app/services/auth_services.dart';
import 'package:gctu_official_app/size_config.dart';
import 'package:gctu_official_app/widgets/button_widgets.dart';


class SignUpForm extends StatefulWidget {
  @override
  _SignUpFormState createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  TextEditingController _nameTEC = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  late String name;
  late String email;
  late String password;
  final auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          buildNameFormField(),
          SizedBox(height: 30),
          buildEmailFormField(),
          SizedBox(height: 30),
          buildPasswordFormField(),
          SizedBox(height: 40),
       GestureDetector(
         onTap: (){
           var _name = _nameTEC.text;
           auth.createUserWithEmailAndPassword(email: email, password: password)
               .then((_){
                 Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => MainPage()));
           });
         },
         child: ButtonWidget(),
       ),
        ],
      ),
    );
  }

  TextFormField buildEmailFormField() {
    return TextFormField(
      obscureText: false,
        onChanged: (val) {
      email = val;
    },

      decoration: InputDecoration(
        labelText: "Email",
        hintText: "Enter Your Email",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(svgIcon: "assets/icons/Mail.svg", key: UniqueKey(),),
      ),
    );
  }

  TextFormField buildPasswordFormField() {
    return TextFormField(
      obscureText: true,
      onChanged: (val) {
        password = val;
      },
      decoration: InputDecoration(
        labelText: "Password",
        hintText: "Enter your password",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
       suffixIcon: CustomSurffixIcon(key: UniqueKey(), svgIcon: "assets/icons/Lock.svg")
      ),
    );
  }

  TextFormField buildNameFormField() {
    return TextFormField(
      controller: _nameTEC,
      keyboardType: TextInputType.name,
      onSaved: (newValue) => name = newValue!,
      onChanged: (val) {
        name = val;
      },

      decoration: InputDecoration(
        labelText: "Username",
        hintText: "Enter your Name",
        // If  you are using latest version of flutter then lable text and hint text shown like this
        // if you r using flutter less then 1.20.* then maybe this is not working properly
        floatingLabelBehavior: FloatingLabelBehavior.always,
        suffixIcon: CustomSurffixIcon(key: UniqueKey(), svgIcon: "assets/icons/User.svg"),
      ),
    );
  }
}
