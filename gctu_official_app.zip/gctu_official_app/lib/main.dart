import 'package:flutter/material.dart';
import 'package:gctu_official_app/screens/home/main_page.dart';
import 'package:gctu_official_app/screens/lecturers_home/lecturers_home_screen.dart';
import 'package:gctu_official_app/screens/round_button_details/bce_course_details.dart';
import 'package:gctu_official_app/screens/sign_in/sign_in_screen.dart';
import 'package:gctu_official_app/screens/splash/splash_screen.dart';
import 'package:gctu_official_app/routes.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:gctu_official_app/theme.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(EducationApp());
}

class EducationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
        title: "Home",
        debugShowCheckedModeBanner: false,
        theme: theme(),

        home: Bce_Course_Details(),

        routes: routes,
      )
    ;
  }
}




