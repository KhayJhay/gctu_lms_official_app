import 'package:flutter/material.dart';

Color deepBlueColors = Color(0x9158FC);
Color whiteColors = Color(0xFEFDFE);
